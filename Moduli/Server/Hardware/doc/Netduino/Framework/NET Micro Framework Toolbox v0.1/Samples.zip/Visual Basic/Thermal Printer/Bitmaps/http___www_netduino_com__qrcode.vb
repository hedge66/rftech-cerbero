﻿'
' This file is generated at http://www.netmftoolbox.com/tools/img_to_bin/
' Original filename: http://www.netduino.com/.qrcode
' Orientation:       column-major order
' Bit order:         Most significant bit
' Inverted:          no
' Timestamp:         2012-12-24 18:48:52
'
Namespace Bitmaps

    ''' <summary>
    ''' http://www.netduino.com/.qrcode bitmap data
    ''' </summary>
    Public Module http___www_netduino_com__qrcode

        ''' <summary>Bitmap width</summary>
        Public Width As Integer = 80
        ''' <summary>Bitmap height</summary>
        Public Height As Integer = 80
        ''' <summary>Bitmap data</summary>
        Public Data() As Byte = {&HFF, &HFF, &HF8, &HE0, &H1, &HFF, &HE3, &HFF, &HFF, &HE0, &HFF, &HFF, &HF8,
         &HE0, &H1, &HFF, &HE3, &HFF, &HFF, &HE0, &HFF, &HFF, &HF8, &HE0, &H1, &HFF, &HE3, &HFF, &HFF,
         &HE0, &HE0, &H0, &H38, &HFF, &HF0, &H0, &H3, &H80, &H0, &HE0, &HE0, &H0, &H38, &HFF, &HF0,
         &H0, &H3, &H80, &H0, &HE0, &HE0, &H0, &H38, &HFF, &HF0, &H0, &H3, &H80, &H0, &HE0, &HE3,
         &HFE, &H38, &HFC, &H7E, &H7, &H3, &H8F, &HF8, &HE0, &HE3, &HFE, &H38, &HFC, &H7E, &H7, &H3,
         &H8F, &HF8, &HE0, &HE3, &HFE, &H38, &HFC, &H7E, &H7, &H3, &H8F, &HF8, &HE0, &HE3, &HFE, &H38,
         &HE3, &HF1, &HC7, &H3, &H8F, &HF8, &HE0, &HE3, &HFE, &H38, &HE3, &HF1, &HC7, &H3, &H8F, &HF8,
         &HE0, &HE3, &HFE, &H38, &HE3, &HF1, &HC7, &H3, &H8F, &HF8, &HE0, &HE3, &HFE, &H38, &HE3, &H8E,
         &H3F, &H3, &H8F, &HF8, &HE0, &HE3, &HFE, &H38, &HE3, &H8E, &H3F, &H3, &H8F, &HF8, &HE0, &HE3,
         &HFE, &H38, &HE3, &H8E, &H3F, &H3, &H8F, &HF8, &HE0, &HE0, &H0, &H38, &H1F, &HFF, &HC7, &HE3,
         &H80, &H0, &HE0, &HE0, &H0, &H38, &H1F, &HFF, &HC7, &HE3, &H80, &H0, &HE0, &HE0, &H0, &H38,
         &H1F, &HFF, &HC7, &HE3, &H80, &H0, &HE0, &HFF, &HFF, &HF8, &HE3, &H8E, &H38, &HE3, &HFF, &HFF,
         &HE0, &HFF, &HFF, &HF8, &HE3, &H8E, &H38, &HE3, &HFF, &HFF, &HE0, &HFF, &HFF, &HF8, &HE3, &H8E,
         &H38, &HE3, &HFF, &HFF, &HE0, &H0, &H0, &H0, &HFC, &H7F, &HF8, &H0, &H0, &H0, &H0, &H0,
         &H0, &H0, &HFC, &H7F, &HF8, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &HFC, &H7F, &HF8, &H0,
         &H0, &H0, &H0, &H1C, &H71, &HF8, &HE0, &H0, &H38, &HFF, &H8F, &HFF, &HE0, &H1C, &H71, &HF8,
         &HE0, &H0, &H38, &HFF, &H8F, &HFF, &HE0, &H1C, &H71, &HF8, &HE0, &H0, &H38, &HFF, &H8F, &HFF,
         &HE0, &HFF, &HF0, &H0, &HFF, &HFF, &HF8, &HFF, &H80, &H38, &HE0, &HFF, &HF0, &H0, &HFF, &HFF,
         &HF8, &HFF, &H80, &H38, &HE0, &HFF, &HF0, &H0, &HFF, &HFF, &HF8, &HFF, &H80, &H38, &HE0, &H3,
         &H8F, &HF8, &HE0, &H71, &HFF, &HFC, &H71, &HF8, &H0, &H3, &H8F, &HF8, &HE0, &H71, &HFF, &HFC,
         &H71, &HF8, &H0, &H3, &H8F, &HF8, &HE0, &H71, &HFF, &HFC, &H71, &HF8, &H0, &H1F, &HF0, &H0,
         &H3, &HFE, &H0, &H3, &HFE, &H7, &HE0, &H1F, &HF0, &H0, &H3, &HFE, &H0, &H3, &HFE, &H7,
         &HE0, &H1F, &HF0, &H0, &H3, &HFE, &H0, &H3, &HFE, &H7, &HE0, &H1C, &HE, &H3F, &HE3, &H81,
         &HC7, &HE3, &H8F, &HC0, &HE0, &H1C, &HE, &H3F, &HE3, &H81, &HC7, &HE3, &H8F, &HC0, &HE0, &H1C,
         &HE, &H3F, &HE3, &H81, &HC7, &HE3, &H8F, &HC0, &HE0, &HFC, &H7F, &HC0, &HFF, &H8E, &H38, &HFF,
         &H8F, &HC0, &HE0, &HFC, &H7F, &HC0, &HFF, &H8E, &H38, &HFF, &H8F, &HC0, &HE0, &HFC, &H7F, &HC0,
         &HFF, &H8E, &H38, &HFF, &H8F, &HC0, &HE0, &H1C, &H71, &HFF, &H3, &H8E, &H7, &HE3, &HFE, &H3F,
         &H0, &H1C, &H71, &HFF, &H3, &H8E, &H7, &HE3, &HFE, &H3F, &H0, &H1C, &H71, &HFF, &H3, &H8E,
         &H7, &HE3, &HFE, &H3F, &H0, &H1F, &H81, &HC7, &HE3, &HFE, &H3F, &HE0, &HE, &H7, &H0, &H1F,
         &H81, &HC7, &HE3, &HFE, &H3F, &HE0, &HE, &H7, &H0, &H1F, &H81, &HC7, &HE3, &HFE, &H3F, &HE0,
         &HE, &H7, &H0, &HFC, &HF, &HFF, &HFC, &H71, &HC7, &HFF, &HFE, &H7, &H0, &HFC, &HF, &HFF,
         &HFC, &H71, &HC7, &HFF, &HFE, &H7, &H0, &HFC, &HF, &HFF, &HFC, &H71, &HC7, &HFF, &HFE, &H7,
         &H0, &H0, &H0, &H0, &HFF, &HF0, &H38, &HE0, &HF, &HC7, &H0, &H0, &H0, &H0, &HFF, &HF0,
         &H38, &HE0, &HF, &HC7, &H0, &H0, &H0, &H0, &HFF, &HF0, &H38, &HE0, &HF, &HC7, &H0, &HFF,
         &HFF, &HF8, &H3, &H8E, &H0, &HE3, &H8F, &HC0, &H0, &HFF, &HFF, &HF8, &H3, &H8E, &H0, &HE3,
         &H8F, &HC0, &H0, &HFF, &HFF, &HF8, &H3, &H8E, &H0, &HE3, &H8F, &HC0, &H0, &HE0, &H0, &H38,
         &HFF, &HFF, &HFF, &HE0, &HF, &HFF, &HE0, &HE0, &H0, &H38, &HFF, &HFF, &HFF, &HE0, &HF, &HFF,
         &HE0, &HE0, &H0, &H38, &HFF, &HFF, &HFF, &HE0, &HF, &HFF, &HE0, &HE3, &HFE, &H38, &H3, &H8E,
         &H38, &HFF, &HFF, &HC7, &HE0, &HE3, &HFE, &H38, &H3, &H8E, &H38, &HFF, &HFF, &HC7, &HE0, &HE3,
         &HFE, &H38, &H3, &H8E, &H38, &HFF, &HFF, &HC7, &HE0, &HE3, &HFE, &H38, &HE3, &H81, &HFF, &H1F,
         &HFE, &H7, &HE0, &HE3, &HFE, &H38, &HE3, &H81, &HFF, &H1F, &HFE, &H7, &HE0, &HE3, &HFE, &H38,
         &HE3, &H81, &HFF, &H1F, &HFE, &H7, &HE0, &HE3, &HFE, &H38, &H0, &HE, &H0, &HFF, &H8F, &HF8,
         &HE0, &HE3, &HFE, &H38, &H0, &HE, &H0, &HFF, &H8F, &HF8, &HE0, &HE3, &HFE, &H38, &H0, &HE,
         &H0, &HFF, &H8F, &HF8, &HE0, &HE0, &H0, &H38, &HFF, &H8F, &HF8, &H3, &H81, &HC0, &HE0, &HE0,
         &H0, &H38, &HFF, &H8F, &HF8, &H3, &H81, &HC0, &HE0, &HE0, &H0, &H38, &HFF, &H8F, &HF8, &H3,
         &H81, &HC0, &HE0, &HFF, &HFF, &HF8, &H3, &HFE, &H3F, &H3, &HF1, &HFF, &HE0, &HFF, &HFF, &HF8,
         &H3, &HFE, &H3F, &H3, &HF1, &HFF, &HE0, &HFF, &HFF, &HF8, &H3, &HFE, &H3F, &H3, &HF1, &HFF,
         &HE0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0,
         &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0,
         &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0,
         &H0, &H0, &H0
         }
    End Module
End Namespace
