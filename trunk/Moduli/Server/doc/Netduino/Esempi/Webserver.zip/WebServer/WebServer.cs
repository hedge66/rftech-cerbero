using System;
using Microsoft.SPOT;
using System.Threading;
using System.Net;
using System.Net.Sockets;

namespace HttpServer
{
	public class WebServer
	{
		OnRequest requestdelegate;


		public WebServer(OnRequest requestdelegate)
		{
			this.requestdelegate = requestdelegate;
		}

		public void Start()
		{
			Socket listener = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
			listener.Bind(new IPEndPoint(IPAddress.Any, 80));
			listener.Listen(100);

			while (true)
			{
				new Request(listener.Accept(), requestdelegate);
			}
		}










	}
}
